'use client';

import { useState } from 'react';
import { Search, X, ChevronDown, Check } from 'lucide-react';
import { Popover, PopoverTrigger, PopoverContent } from '@/components/ui/popover';
import { FilterSelect } from '@/components/ui/filter-select';
import { cn } from '@/lib/utils';
import type { PaginationMeta } from '@/lib/api';

const MOVEMENT_TYPE_OPTIONS = [
  { key: 'procurement', value: 'Procurement' },
  { key: 'manual_adjustment', value: 'Adjustment' },
  { key: 'borrow_release', value: 'Release' },
  { key: 'borrow_return', value: 'Return' },
  { key: 'damage', value: 'Damage or loss' },
];

const REFERENCE_TYPE_OPTIONS = [
  { key: 'borrow_request', value: 'Borrow request' },
  { key: 'inventory_movement', value: 'Inventory movement' },
  { key: 'external_reference', value: 'External reference' },
];

export function LedgerFiltersBar({
  itemId,
  onItemIdChange,
  movementType,
  onMovementTypeChange,
  referenceId,
  onReferenceIdChange,
  referenceType,
  onReferenceTypeChange,
  meta,
}: {
  itemId: string;
  onItemIdChange: (v: string) => void;
  movementType: string;
  onMovementTypeChange: (v: string) => void;
  referenceId: string;
  onReferenceIdChange: (v: string) => void;
  referenceType: string;
  onReferenceTypeChange: (v: string) => void;
  meta?: PaginationMeta | null;
}) {


  return (
    <div className="flex flex-col gap-3 p-4 border-b border-border">
      <div className="flex items-center gap-3 flex-wrap">
        <div className="relative flex-1 min-w-[200px] max-w-md">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search equipment..."
            value={itemId}
            onChange={(e) => onItemIdChange(e.target.value)}
            className="w-full h-11 pl-12 pr-4 rounded-lg bg-muted/50 border border-border text-sm placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary/40 transition-all"
          />
          {itemId && (
            <button
              type="button"
              onClick={() => onItemIdChange('')}
              aria-label="Clear item search"
              className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-muted-foreground hover:text-foreground rounded-md hover:bg-muted transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
        {meta && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span className="font-medium text-foreground">{meta.total}</span>
            <span>movement{meta.total !== 1 ? 's' : ''} total</span>
          </div>
        )}
      </div>
      <div className="flex items-center gap-3 flex-wrap">
        <span className="text-xs font-medium text-muted-foreground mr-1">Filter by:</span>
        <FilterSelect
          value={movementType}
          onChange={onMovementTypeChange}
          options={MOVEMENT_TYPE_OPTIONS.map(o => ({ key: o.key, label: o.value }))}
          placeholder="All movement types"
          align="start"
        />

        <div className="relative min-w-[220px]">
          <input
            type="text"
            placeholder="Reference ID"
            value={referenceId}
            onChange={(e) => onReferenceIdChange(e.target.value)}
            className="w-full h-10 pl-3 pr-9 rounded-lg bg-muted/50 border border-border text-sm placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary/40 transition-all"
          />
          {referenceId && (
            <button
              type="button"
              onClick={() => onReferenceIdChange('')}
              aria-label="Clear reference id"
              className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-muted-foreground hover:text-foreground rounded-md hover:bg-muted transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        <FilterSelect
          value={referenceType}
          onChange={onReferenceTypeChange}
          options={REFERENCE_TYPE_OPTIONS.map(o => ({ key: o.key, label: o.value }))}
          placeholder="All reference types"
          align="start"
        />
      </div>
    </div>
  );
}
