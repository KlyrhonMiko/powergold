"""PowerGold systems package."""
