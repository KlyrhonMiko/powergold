"""Pydantic/SQLModel schemas package."""
