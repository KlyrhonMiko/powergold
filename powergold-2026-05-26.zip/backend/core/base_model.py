from sqlalchemy import JSON, Text
from datetime import datetime
from uuid import UUID, uuid7

from sqlmodel import Field, SQLModel

from utils.time_utils import get_now_manila


class BaseModel(SQLModel):

    id: UUID = Field(default_factory=uuid7, primary_key=True)
    created_at: datetime = Field(default_factory=get_now_manila, nullable=False)
    updated_at: datetime = Field(default_factory=get_now_manila, nullable=False)
    is_deleted: bool = Field(default=False, nullable=False)
    deleted_at: datetime | None = Field(default=None, nullable=True)
    is_archived: bool = Field(default=False, nullable=False, index=True)
    archived_at: datetime | None = Field(default=None, nullable=True)
    retention_tags: list[str] | None = Field(default=None, sa_type=JSON)

class ConfigurationBase(BaseModel):
    system: str = Field(index=True, max_length=50)
    key: str = Field(index=True, max_length=100)
    value: str = Field(sa_type=Text)
    category: str = Field(default="general", max_length=50)
    description: str | None = Field(default=None, max_length=500)
    crucial: bool = Field(default=False, nullable=False)
