from typing import List
from fastapi import WebSocket

class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)

    async def broadcast_catalog_update(self):
        """Notify all connected clients that the catalog has changed."""
        message = {"type": "catalog_update"}
        for connection in self.active_connections[:]:
            try:
                await connection.send_json(message)
            except Exception:
                # Handle disconnected clients gracefully
                self.disconnect(connection)

# Global manager instance
manager = ConnectionManager()
